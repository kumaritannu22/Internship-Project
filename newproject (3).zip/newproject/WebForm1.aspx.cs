﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace newproject
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string constr = "Data Source=.\\sqlexpress;Initial Catalog=rites;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //string constr = System.Configuration.ConfigurationManager.ConnectionStrings["binddropdown"].ToString();
                // connection string  
                SqlConnection con = new SqlConnection(constr);
                con.Open();

                SqlCommand com = new SqlCommand("select * from module", con);
                // table name   
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataSet ds = new DataSet();
                da.Fill(ds);  // fill dataset  
                DropDownList1.DataTextField = ds.Tables[0].Columns["name"].ToString(); // text field name of table dispalyed in dropdown       
                DropDownList1.DataValueField = ds.Tables[0].Columns["id"].ToString();
                // to retrive specific  textfield name   
                DropDownList1.DataSource = ds.Tables[0];      //assigning datasource to the dropdownlist  
                DropDownList1.DataBind();  //binding dropdownlist  

                SqlCommand com2 = new SqlCommand("select * from priority", con);
                // table name   
                SqlDataAdapter da2 = new SqlDataAdapter(com2);
                DataSet ds2 = new DataSet();
                da2.Fill(ds2);  // fill dataset  
                DropDownList2.DataTextField = ds2.Tables[0].Columns["name"].ToString(); // text field name of table dispalyed in dropdown       
                DropDownList2.DataValueField = ds2.Tables[0].Columns["id"].ToString();
                // to retrive specific  textfield name   
                DropDownList2.DataSource = ds2.Tables[0];      //assigning datasource to the dropdownlist  
                DropDownList2.DataBind();  //binding dropdownlist  

                /* SqlCommand com3 = new SqlCommand("select * from request", con);
                 // table name   
                 SqlDataAdapter da3 = new SqlDataAdapter(com3);
                 DataSet ds3 = new DataSet();
                 da3.Fill(ds3);  // fill dataset  
                 DropDownList3.DataTextField = ds3.Tables[0].Columns["name"].ToString(); // text field name of table dispalyed in dropdown       
                 DropDownList3.DataValueField = ds3.Tables[0].Columns["id"].ToString();
                 // to retrive specific  textfield name   
                 DropDownList3.DataSource = ds3.Tables[0];      //assigning datasource to the dropdownlist  
                 DropDownList3.DataBind();  //binding dropdownlist */


            }

            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        dt.TableName = "requestid";
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
            */

        }
        protected void Button1_Click(object sender, EventArgs e)
        {


            string cs = "Data Source=.\\sqlexpress;Initial Catalog=rites;Integrated Security=True";

            SqlConnection conn = new SqlConnection(cs);

            //string query = string.Format("insert into user('{0}','{1}',{2},'{3}','{4}','{5}')", init, sbu, srno, newentry, newdev, aname);


            conn.Open();
            SqlCommand command = new SqlCommand("INSERT INTO REQUEST(INITIATOR,SBU_FUNC,SNO,NEW_ENTRY,NEW_DEVELOPMENT,AUTHORIZED_NAME,AUTHORIZED_DATE,IMPACT_ANALYSIS,RISK_ASSESS,ROLL_BACK_PLAN,APPROVED_NAME,APPROVED_DATE,DONE_NAME,DATE_OF_IMPLEMENTATION,TEST_COND,TEST_DATA,RESULT) VALUES (@INITIATOR, @SBU_FUNC, @SNO, @NEW_ENTRY, @NEW_DEVELOPMENT, @AUTHORIZED_NAME, @AUTHORIZED_DATE, @IMPACT_ANALYSIS,@RISK_ASSESS,@ROLL_BACK_PLAN,@APPROVED_NAME,@APPROVED_DATE,@DONE_NAME,@DATE_OF_IMPLEMENTATION,@TEST_COND,@TEST_DATA,@RESULT)", conn);
            command.Parameters.AddWithValue("@INITIATOR", Initiator.Text);
            command.Parameters.AddWithValue("@SBU_FUNC", sfun.Text);
            command.Parameters.AddWithValue("@SNO", TextBox1.Text);
            command.Parameters.AddWithValue("@NEW_ENTRY", TextBox2.Text);
            command.Parameters.AddWithValue("@NEW_DEVELOPMENT", TextBox3.Text);
            command.Parameters.AddWithValue("@AUTHORIZED_NAME", TextBox4.Text);
            command.Parameters.AddWithValue("@AUTHORIZED_DATE", txtAuthorizationDate.Text);
            command.Parameters.AddWithValue("@IMPACT_ANALYSIS", TextBox7.Text);
            command.Parameters.AddWithValue("@RISK_ASSESS", TextBox8.Text);
            command.Parameters.AddWithValue("@ROLL_BACK_PLAN", TextBox9.Text);
            command.Parameters.AddWithValue("@APPROVED_NAME", TextBox10.Text);
            command.Parameters.AddWithValue("@APPROVED_DATE", txtApprovedDate.Text);
            command.Parameters.AddWithValue("@DONE_NAME", TextBox13.Text);
            command.Parameters.AddWithValue("@DATE_OF_IMPLEMENTATION", txtDateOfImplementation.Text);
            command.Parameters.AddWithValue("@TEST_COND", TextBox16.Text);
            command.Parameters.AddWithValue("@TEST_DATA", TextBox17.Text);
            command.Parameters.AddWithValue("@RESULT", TextBox18.Text);
            command.ExecuteNonQuery();


            conn.Close();



            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "K", "alert('Change Successfully')", true);


        }
        protected void Button2_Click(Object sender, EventArgs e)
        {
            Response.Redirect("Report.aspx");
        }
    }
}







       
